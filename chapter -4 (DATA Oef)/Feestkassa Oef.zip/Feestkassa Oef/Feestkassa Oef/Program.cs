﻿using System;

namespace Feestkassa_Oef
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Party cashier!");
            Console.WriteLine();
            double a; // Value of Fries
            double b; //Value of Queen Snacks
            double c; //Value of Ice Cream
            double d; //Value of Drinks
            double t; //Total 
            a = 20;
            b = 5;
            c = 2;
            d = 5;
            
            double w; //quantity of Fries
            double x; //quantity of Queen Snacks 
            double y; //quantity of  Ice Cream
            double z; //quantity of Drinks
            Console.WriteLine("Fries?:");
            w = double.Parse(Console.ReadLine());
            Console.WriteLine("Intermediate price = " +  (w * a)  +  " euros ");
            Console.WriteLine();


            Console.WriteLine("Queen Snacks?:");
            x = double.Parse(Console.ReadLine());
            Console.WriteLine("Intermediate price = " +  ( w * a)   +   " euros "  +   " + "    +   (x * b)   +   " euros ");
            Console.WriteLine();

            Console.WriteLine("Ice Cream?:");
            y = double.Parse(Console.ReadLine());
            Console.WriteLine("Intermediate price = " +  ((w * a)   +  " euros "  +   " + "   +   (x * b)   +   " euros "   +    " + "    +   (y * c))   +   " euros ");
            Console.WriteLine();

            Console.WriteLine("Drinks?:");
            z = double.Parse(Console.ReadLine());
            Console.WriteLine("Intermediate price = "  +  ((w * a)  +  " euros "  +   " + "   +   (x * b)   +   " euros "   +    " + "    +   (y * c)   +   " euros "   +    " + "   +   (z * d))  +  " euros ");
            Console.WriteLine();

            Console.WriteLine("*******************************");
            Console.WriteLine();
            t = ((w * a) + (x * b) + (y * c) + (z * d));
            Console.WriteLine("The total amount to be paid is : " + t +   " euros ");

        }
    }
}
