﻿using System;

namespace Calculate_BMI_Oef
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(" User BMI!");

            Console.WriteLine("Weight in Kg");
            
            double weight = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("Height in m");
            double height = Convert.ToDouble(Console.ReadLine());


            double BMI;
            BMI = weight / (height) * (height);
           

            Console.WriteLine($"BMI¨: {Math.Round(BMI)}");
            











        }
    }
}
