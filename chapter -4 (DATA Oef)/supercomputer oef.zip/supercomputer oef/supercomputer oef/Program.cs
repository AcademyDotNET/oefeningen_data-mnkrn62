﻿using System;

namespace supercomputer_oef
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("using breakpoint take out mean");
            
            Console.WriteLine("1st value:");
            double X = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("2nd value:");
            double Y = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("3rd value:");
            double Z = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine((X + Y + Z)/3);




        }
    }
}
