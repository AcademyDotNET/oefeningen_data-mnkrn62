﻿using System;

namespace Op_de_poef_oef
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("op de poef !");
            Console.WriteLine("Enter Amount");
            double a, b, c, d, e, T;
            a = double.Parse(Console.ReadLine());
            Console.WriteLine("The ottoman stands at "  + a  +  " euros.");  
            Console.WriteLine("Enter Amount");
            b = double.Parse(Console.ReadLine());
            Console.WriteLine("The ottoman stands at " + (a + b) + " euros.");
            Console.WriteLine("Enter Amount");
            c = double.Parse(Console.ReadLine());
            Console.WriteLine("The ottoman stands at " + (a + b + c) + " euros.");
            Console.WriteLine("Enter Amount");
            d = double.Parse(Console.ReadLine());
            Console.WriteLine("The ottoman stands at " + (a + b + c +d) + " euros.");
            Console.WriteLine("Enter Amount");
            e = double.Parse(Console.ReadLine());
            Console.WriteLine("The ottoman stands at " + (a + b + c + d + e) + " euros.");
             T = a + b + c + d + e;
            Console.WriteLine("'**************************");
            Console.WriteLine("The total of the pouf is: " + T + " euros and will take " + (T/10) +   " weeks to be paid in full."); //user is paying 10 euro per week.
        }

    }
}
