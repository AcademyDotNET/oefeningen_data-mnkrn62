﻿using System;

namespace Geomatric_fun_oef
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Geomatric Fun!");
            Console.WriteLine("Give the value of angle in degree");
           
            double angle = Convert.ToDouble(Console.ReadLine());
            double radians = angle * Math.PI / 180.0;
            Console.WriteLine($"Sine of angle is:{Math.Sin(radians)}");
            Console.WriteLine($"Cosine of angle is:{Math.Cos(radians)}");
            Console.WriteLine($"Tangent of angle is:{Math.Tan(radians)}");

        }


    }
}
